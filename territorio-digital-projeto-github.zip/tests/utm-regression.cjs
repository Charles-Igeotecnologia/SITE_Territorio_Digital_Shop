const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const src=fs.readFileSync(process.argv[2]||require('path').join(__dirname,'../assets/js/app.js'),'utf8');
const fn=src.slice(src.indexOf('function utmInfo(){'),src.indexOf('function renderUTM(){'));
const c={lat:'-3.1190',lon:'-60.0217'};const ctx={ $:x=>({value:x==='#uLat'?c.lat:c.lon})};vm.createContext(ctx);vm.runInContext(fn,ctx);
const reference=ctx.utmInfo();assert.equal(reference.epsg,31980);assert.ok(Math.abs(reference.E-831071.8222505483)<0.01);assert.ok(Math.abs(reference.N-9654784.864101604)<0.01);console.log('PASS Manaus x PROJ (tolerancia 1 cm)');
const cases=[['Manaus','-3.1190','-60.0217',20],['longitude limite','0','180',60],['abaixo da faixa UTM','-81','-60',null],['texto invalido','-3abc','-60',null],['vazio','','-60',null]];
let failures=0;for(const [name,lat,lon,zone]of cases){c.lat=lat;c.lon=lon;try{const u=ctx.utmInfo();if(zone===null)assert.equal(u,null);else assert.equal(u.zone,zone);console.log('PASS',name)}catch(e){failures++;console.log('FAIL',name)}}process.exitCode=failures?1:0;
