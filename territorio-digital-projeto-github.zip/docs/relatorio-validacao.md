# Relatório de inspeção e validação

Data: 17/10/2026 · domínio: https://territoriodigital.shop/ · situação: preparado localmente, aguardando autorização para publicação.

## Resultado

O HTML original funciona como portal estático. Mantidos os 27 registros completos das publicações e as 32 imagens. CSS e Leaflet conferidos contra o original; as imagens foram extraídas com bytes idênticos, registrados em `preservation.json`. O HTML principal passou de 10.705.217 para cerca de 27 mil bytes; o restante está em arquivos separados. Isso não representa redução equivalente do peso total do site.

## Correções verificadas

- Mapa escuro: removido a pedido do proprietário após identificar erro de domínio e exigência de chave do provedor CARTO. Mantidos o satélite e os rótulos Esri.
- UTM: rejeição de texto misturado aos números e latitude fora de −80° a 84°; longitude 180° limitada ao fuso 60.
- Agenda: bloqueio de datas anteriores à mínima permitida; cálculo da data mínima usando America/Manaus.
- Metadados: canonical, URL social, imagem social absoluta, robots e sitemap com o domínio informado. O arquivo da imagem social, antes somente incorporado, agora existe no caminho público.

O diff das mudanças funcionais está em `alteracoes-funcionais.diff`. Nenhum texto editorial, marca, contato, número de registro ou geometria foi corrigido por inferência.

## Testes executados

Chrome 155, execução isolada por Playwright. Treze grupos de verificação: renderização, busca e resultado vazio, categorias/paginação, leitor/download/link direto/compartilhamento por cópia, atlas/popups/satélite/rótulos/zoom, Hub/filtros/persistência/cópia, checklist/conversor, agenda, formulário/solicitação de dados e layouts em 390/768/1440 px, além dos recursos locais e âncoras.

Resultado: nenhum erro JavaScript, nenhum HTTP 4xx/5xx e nenhuma falha de rede efetiva na rodada concluída. Cancelamentos de tiles provocados por zoom, troca de camada e recarga foram registrados separadamente como `ERR_ABORTED`. Não são erros DNS ou HTTP e não foram ocultados das evidências.

UTM: comparação independente com PyProj 3.7.2 / PROJ para SIRGAS 2000, de EPSG:4674 para EPSG:31980, longitude −60,0217°, latitude −3,1190°: E 831071,8222505483 m; N 9654784,864101604 m. Diferença abaixo de 1 cm no ponto de teste. Isso valida a conta amostrada, não a precisão de dados de campo nem todas as zonas do mundo. O utilitário não transforma datum e não implementa exceções globais como Noruega/Svalbard.

## Limites e pendências

- HTTPS do domínio respondeu 200, título “Página padrão”; não foi acessado o painel Hostinger, nem alterado arquivo remoto, DNS ou certificado.
- Repositório GitHub ainda não informado. Git local iniciado sem commit, remote ou push.
- Agenda é um pedido manual por e-mail/WhatsApp; não consulta disponibilidade, reserva horários ou integra automaticamente com a conta Google.
- Contato utiliza mailto porque Formspree está vazio. Validação local e preparação de links conferidas; entrega real, aplicativo de e-mail e envio não testados. As integrações opcionais Formspree/agendaUrl exigem homologação própria antes de ativar.
- Território Agêntico, Laboratório e API apresentam conteúdo institucional; este arquivo não contém agentes de IA executáveis, API geoespacial, autenticação ou banco corporativo. O acervo está sob consulta/em breve conforme o conteúdo recebido.
- Fontes e tiles externos dependem de internet e das condições dos provedores. Foram testados os serviços efetivamente carregados; não foi auditada a disponibilidade de todos os 26 portais do catálogo.
- O botão Baixar imagem entrega o WebP incorporado no arquivo recebido. Os PNG/JPEG originais citados nos dados não vieram anexos; não foram recriados.
- Acessibilidade, desempenho em rede móvel, Safari/Firefox, cabeçalhos no servidor e ambiente produtivo não foram certificados por estes testes.

## Referências técnicas consultadas

- Hostinger: https://www.hostinger.com/support/1583302-how-to-deploy-a-git-repository-in-hostinger/
- GitHub: https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github
- CARTO, padrões oficiais: https://github.com/CartoDB/basemap-styles
- Leaflet 1.9.4: https://leafletjs.com/reference.html
- UTM / PROJ: https://proj.org/en/stable/operations/projections/utm.html
